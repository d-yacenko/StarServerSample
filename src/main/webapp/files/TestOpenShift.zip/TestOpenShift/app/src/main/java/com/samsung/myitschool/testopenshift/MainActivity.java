package com.samsung.myitschool.testopenshift;

import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.simpleframework.xml.Serializer;
import org.simpleframework.xml.core.Persister;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.logging.Logger;

public class MainActivity extends AppCompatActivity {

    EditText name,number,date;
    TextView out;
    Phonebook phonebook;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name=(EditText)findViewById(R.id.name);
        number=(EditText)findViewById(R.id.number);
        date=(EditText)findViewById(R.id.date);
        out=(TextView)findViewById(R.id.out);
        phonebook=new Phonebook();
    }
    public void add(View V){
        String in_name=name.getText().toString();
        Date in_date= null;
        try {
            in_date = new SimpleDateFormat("dd.MM.yyyy",new Locale("ru")).parse(date.getText().toString());
        } catch (ParseException e) {
            Toast.makeText(this, "неверный формат даты", Toast.LENGTH_LONG).show();
        }
        long in_number=Long.parseLong(number.getText().toString());
        Contact contact=new Contact(in_name,in_date,in_number);
        phonebook.contacts.add(contact);
        send2Server(contact);
        Toast.makeText(this, "Добавлено", Toast.LENGTH_LONG);
    }

    public void clear(View V){
        out.setText("");
    }

    public void load(View V){
        getFromServer();
        String str="";
        out.setText(phonebook.toString());
        Toast.makeText(this, "Загружено", Toast.LENGTH_LONG);
    }

    private void send2Server(final Contact contact) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL url = new URL("https://conduit-myitschool.rhcloud.com/conduit/HelloWorld");
                    URLConnection connection = url.openConnection();
                    connection.setDoOutput(true);
                    BufferedOutputStream out = new BufferedOutputStream(connection
                            .getOutputStream());
                    out.write("put\n".getBytes());
                    Serializer ser = new Persister();
                    ser.write(contact, out);
                    out.flush();
                    out.close();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    String returnString = reader.readLine();
                    Log.e("NETWORK", "Ответ сервера "+returnString);
                    reader.close();
                }catch(Exception e){
                    Log.e("NETWORK", "Ошибка передачи на сервер - " + e.getMessage());
                }

            }
        }).start();
    }

    private void getFromServer() {
        new Thread(new Runnable() {
            ArrayList<Contact> rez=new ArrayList<Contact>();
            @Override
            public void run() {
                try {
                    URL url = new URL("https://conduit-myitschool.rhcloud.com/conduit/HelloWorld");
                    URLConnection connection = url.openConnection();
                    connection.setDoOutput(true);
                    BufferedOutputStream out = new BufferedOutputStream(connection
                            .getOutputStream());
                    out.write("get\n".getBytes());
                    out.flush();
                    out.close();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    Serializer ser = new Persister();
                    phonebook=ser.read(Phonebook.class,reader);
                    String returnString = reader.readLine();
                    Log.e("NETWORK", "Ответ сервера "+returnString);
                    reader.close();
                }catch(Exception e){
                    Log.e("NETWORK", "Ошибка получения с сервера - " + e.getMessage());
                }
            }
        }).start();
    }

}